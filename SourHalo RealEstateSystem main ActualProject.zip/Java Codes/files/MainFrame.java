import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTabbedPane;

/** The main window: one tab per screen, plus the background expiry thread. */
public class MainFrame extends JFrame {

    private static final long EXPIRY_INTERVAL_MILLIS = 5 * 60 * 1000L; // every 5 minutes

    private final List<BasePanel> panels = new ArrayList<>();
    private final JTabbedPane tabs = new JTabbedPane();
    private final JLabel statusBar = new JLabel(" Connected. Waiting for the first expiry check...");
    private final ExpiryScheduler scheduler;

    public MainFrame() {
        super("EstateEase - Property Rental Management");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        addTab("Dashboard", new ReportsPanel());
        addTab("Properties", new PropertyPanel());
        addTab("Agreements & Payments", new AgreementPanel());
        addTab("Maintenance", new MaintenancePanel());
        addTab("Owners", new PeoplePanel(new Owner()));
        addTab("Tenants", new PeoplePanel(new Tenant()));

        // Reload a tab's data whenever the user switches to it.
        tabs.addChangeListener(e -> {
            BasePanel selected = (BasePanel) tabs.getSelectedComponent();
            if (selected != null) {
                selected.refresh();
            }
        });

        statusBar.setBorder(BorderFactory.createEmptyBorder(3, 6, 3, 6));
        add(tabs, BorderLayout.CENTER);
        add(statusBar, BorderLayout.SOUTH);

        setSize(1100, 650);
        setLocationRelativeTo(null);

        // Background thread that expires old agreements automatically.
        scheduler = new ExpiryScheduler(EXPIRY_INTERVAL_MILLIS, (expired, error) -> onExpiryCheck(expired, error));
        scheduler.start();

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                scheduler.stop();
            }
        });

        panels.get(0).refresh(); // the change listener does not fire for the first tab
    }

    private void addTab(String title, BasePanel panel) {
        panels.add(panel);
        tabs.addTab(title, panel);
    }

    /** Called on the Swing thread by the ExpiryScheduler after every check. */
    private void onExpiryCheck(int expired, String error) {
        String time = LocalTime.now().withNano(0).toString();
        if (error != null) {
            statusBar.setText(" Automatic expiry check failed at " + time + ": " + error);
            return;
        }
        statusBar.setText(" Last automatic expiry check: " + time
                + "   |   agreements expired this session: " + scheduler.getTotalExpired());
        if (expired > 0) {
            for (BasePanel panel : panels) {
                panel.refresh(); // properties may have become Available again
            }
        }
    }
}
